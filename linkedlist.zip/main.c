#include "LinkedList.h"
#include <stdio.h>

int main (int argc, char** argv) {
  struct LinkedList* list = create("Hello");
  insertAfter(list, "Hello", " ");
  insertAfter(list, " ", "World");
  //insertAfter(list, "World", "\n");
  
  //print(list);
  
  //printf("%i", contains(list, "Hello World"));
  
  //struct LinkedList* newList = copy(list);
  //insertAfter(list, " ", "new");
  //print(newList);
  
  //test only insertBefore
  insertBefore(list, "Hello", "new");
  delete(list, "new");
  print(list);
  //visit(printNode(
}

char* printNode(struct Node* oldn)
{
	printf("%c",oldn->data);
}