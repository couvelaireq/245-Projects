struct Node {
  struct Node* next;
  char* data;
};

struct LinkedList {
  struct Node* head;
};

struct LinkedList* create(char* data);
int insertBefore (struct LinkedList* list, char* sValue, char* value);
struct LinkedList* insertAfter(struct LinkedList* list, char* valueToFind, char* newValue);
void print(struct LinkedList* lst);
int delete(struct LinkedList* list, char* value);
void visit (struct LinkedList* list, 
	void (*visitFunc) (struct Node* value, void* d), 
	void* data);

/* 
Returns 1 if the list named "list" contains a node whose value is sValue, 0 if not1
*/
int contains (struct LinkedList* list, char* sValue);

struct LinkedList* copy (struct LinkedList* src);