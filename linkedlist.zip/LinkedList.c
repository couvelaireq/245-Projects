#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"

struct Node* createNode (char* data) {
  struct Node* node = (struct Node*) malloc(sizeof(struct Node));
  //  Make sure memory was successfully allocated for the new node
  if (node == NULL) {
	  return NULL;
  }
  node->next = NULL;
  node->data = data;
  return node;
}

struct LinkedList* create (char* data) {
  struct LinkedList* newList = (struct LinkedList*) malloc(sizeof(struct LinkedList));
  if (newList != NULL) {
    newList->head = createNode(data);
  }
  return newList;
}

/*
Inserts a new node with value "value" into the list
referenced by "list" so that the new node comes before
the node with value "sValue"
 
Returns 0 if no node with value "sValue" can be found
in the list. Returns -1 if no memory can be allocated for a new node, and 1 
if the new node is created.
 */
int insertBefore(struct LinkedList* list, char* sValue, char* value){
	struct Node* currentNode = list->head; //currentNode initialized to head
	struct Node* previousNode = list->head; // previousNode initialized to head
	
	if(list->head->data == sValue){
		insertAfter(list, list->head->data,list->head->data);
		list->head->data = value;
	}
 else{ while (currentNode != NULL && strcmp(currentNode->data, sValue) != 0) {
    //set previous to currentNode
	previousNode = currentNode;
	//set currentNode to next node
	currentNode = currentNode->next;
  }
  
  //  If we didn't find the value, return 0 to indicate that fact
  if (currentNode == NULL) {
    return 0;
  }
  // return -1 if no memory can be allocated for a new node
  if(createNode(value)== NULL){
	  return -1;
    }
  
  //  Otherwise, create a new node, and set up the pointers appropriately
  struct Node* newNode = createNode(value);
  if (newNode != NULL) {
    // set up pointers correctly 
	newNode->next= currentNode;
	previousNode->next = newNode;
  }
 }
  return 1;
}

struct LinkedList* insertAfter (struct LinkedList* list, char* insertNodeValue, char* newValue) {
  struct Node* currentNode = list->head;
  while (currentNode != NULL && strcmp(currentNode->data, insertNodeValue) != 0) {
    currentNode = currentNode->next; 
  }
  
  //  If we didn't find the value, return NULL to indicate that fact
  if (currentNode == NULL) {
    return NULL;
  }
  
  //  Otherwise, create a new node, and set up the pointers appropriately
  struct Node* newNode = createNode(newValue);
  if (newNode != NULL) {
    newNode->next = currentNode->next;
    currentNode->next = newNode;
  }
  return list;
}

void print(struct LinkedList* lst) {
struct Node* tmp = lst->head;
  while (tmp != NULL) {
    printf ("%s", tmp->data);
    tmp = tmp->next;
  }
}

int contains (struct LinkedList* list, char* sValue) {
	struct Node* tmp = list->head;
  while (tmp != NULL) {
    if(strcmp((tmp->data),sValue) == 0) {
		return 1;
	}
    tmp = tmp->next;
  }
  return 0;
}

struct LinkedList* copy (struct LinkedList* src) {
	struct Node* tmp = src->head;
	struct LinkedList* newList = create(tmp->data);
	char* prev = tmp->data;
	tmp = tmp->next;
	
	while (tmp != NULL) {
		insertAfter(newList, prev, tmp->data);
		prev = tmp->data;
		tmp = tmp->next;
	}
	
	return newList;
}
/* 
Deletes the node in the list with value 'value'
returns 0 if such a node cannot be found; otherwise
returns 1
*/
int delete(struct LinkedList* list, char* value){
	struct Node* currentNode = list->head; //currentNode initialized to head
	struct Node* previousNode = list->head; // previousNode initialized to head
	
	if(list->head->data == value){
		list->head= currentNode->next;
		return 1;
	}
	else{ 
	while (currentNode != NULL && strcmp(currentNode->data, value) != 0) {
    //set previous to currentNode
	previousNode = currentNode;
	//set currentNode to next node
	currentNode = currentNode->next;
	}
	if(currentNode!=NULL){
	  previousNode->next=currentNode->next;
	  free(currentNode);
	  return 1;
  }
  else{
	  return 0;
	}
}
	
}

/* Visits each node of the list, calling the function
pointed to be "visitFunc" for each node
*/
void visit (struct LinkedList* list, void (*visitFunc) (struct Node* value, void* d), void* data){
	struct Node* current = list->head;
	while(current != NULL) {
		visitFunc(current, data);
		current = current->next;
	}
}